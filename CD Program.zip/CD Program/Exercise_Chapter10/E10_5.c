/*E10.5*/
#include<stdio.h>
int main(void)
{
	char str[]="Vijaynagar";
//	str=str+5;
	printf("%s\n",str);
	return 0;
}
