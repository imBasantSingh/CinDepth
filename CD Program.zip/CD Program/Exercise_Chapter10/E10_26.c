/*E10.26*/
#include<stdio.h>
int main(void)
{
	char *ptr;
	ptr="My name is %s and age is %d\n";
	printf(ptr,"Ranju",30);
	return 0;
}
