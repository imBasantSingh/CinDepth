/*P5.17 Program to print numbers from 1 to 10 using for loop*/
#include<stdio.h>
int main(void)
{
	int i;
	for(i=1; i<=10; i++)
		printf("%d\t",i);
	printf("\n");
	return 0;
}