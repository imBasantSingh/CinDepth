/*E31_2*/
#include<stdio.h>
#define MSSG  printf("If you lapse,don't collapse\n");
int main(void)
{
	MSSG
	return 0;
}