/*E13_21*/
#include<stdio.h>
int main(void)
{
	#line 100 "system.c"
	printf("%d   %s\n",__LINE__,__FILE__);
	return 0;
}